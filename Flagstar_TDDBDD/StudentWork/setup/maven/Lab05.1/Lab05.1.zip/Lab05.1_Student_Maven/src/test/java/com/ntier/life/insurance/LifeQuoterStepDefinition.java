package com.ntier.life.insurance;

import junit.framework.Assert;

import org.mockito.Mockito;

import com.thirdparty.service.MedicalRatingService;

import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
import cucumber.runtime.PendingException;

public class LifeQuoterStepDefinition {
	 
}
