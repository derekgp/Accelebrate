package com.ntier.life.insurance;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
 
 
 
@RunWith(Cucumber.class)
@CucumberOptions(plugin={"pretty"}, 
features="test/features", 
monochrome=true, tags={"@Singular"})
public class RunTests {
 
}
