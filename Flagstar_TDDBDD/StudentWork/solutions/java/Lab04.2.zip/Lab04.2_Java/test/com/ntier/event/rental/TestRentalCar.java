package com.ntier.event.rental;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
 
import org.junit.Before;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.any;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;

public class TestRentalCar {
	
	private RentalCar rentalCar;
	private HotelRoom hotelRoom;
	
	
	@Before
	public void setUp(){
		rentalCar = new RentalCar(21, "Ford", "Anglia");
		hotelRoom = new HotelRoom(100, false);
	}
	@Test
	public void testRentalCar(){
		 assertNotNull(rentalCar);
		 assertThat(rentalCar.toString(), is("21 Ford Anglia"));
		 assertThat(rentalCar.getMake(), any(String.class));
	}
	@Test
	public void testHotelRoom(){
		assertNotNull(hotelRoom);
		assertThat(hotelRoom.toString(), is("100 false"));
		assertThat(hotelRoom.toString(), not("200 false"));
	}

}
