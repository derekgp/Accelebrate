package com.ntier.life.insurance;

import com.thirdparty.service.MedicalRatingService;

import org.easymock.EasyMock;
import org.junit.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class LifeQuoteTestMokito {

	private static Insurable insured;
	private static LifeQuote quote;
	private  MedicalRatingService service;


	@Before
	public  void setUp() throws Exception {
		insured = new Insurable();
		insured.setAge(31);
		insured.setGender("M");
		insured.setMedicalId(10001);        
		quote = new LifeQuote(insured);
        service =  mock(MedicalRatingService.class);
		when(service.requestMedicalRating(10001)).thenReturn("EXCELLENT");
        when(service.requestMedicalRating(8001)).thenReturn("GOOD");
	    when(service.requestMedicalRating(7005)).thenReturn("GOOD");
		when(service.requestMedicalRating(1001)).thenReturn("POOR");
		quote.setMedRatingService(service);
	}

	@Test
	public void testMedicalRatingService() throws Exception {
		 MedicalRatingService mrs = quote.getMedRatingService();
         assertEquals(30.18, quote.getLifeQuote(), .01);
         insured.setMedicalId(8001);
         assertEquals(43.12, quote.getLifeQuote(), .01);
         insured.setMedicalId(7005);
         assertEquals(43.12, quote.getLifeQuote(), .01);
         insured.setMedicalId(1001);
         assertEquals(56.06, quote.getLifeQuote(), .01);
    }

    @After
    public void after(){
         verify(service).requestMedicalRating(10001);
         verify(service).requestMedicalRating(8001);
         verify(service).requestMedicalRating(7005);
         verify(service).requestMedicalRating(1001);
	}
	


}
