package com.ntier.insurance;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(value= Parameterized.class)
public class QuoteParameterizedMultiDriverTest {
	
 
	private List list;
	private double result; 
	
	@Parameters
	public static Collection<Object[]> parameters(){
		 List<Driver> list1 = new ArrayList<Driver>();
		 list1.add(new Driver(24, "M", 2));
		 list1.add(new Driver(25, "M", 2));
		 
		 List<Driver>  list2 = new ArrayList<Driver>();
		 list2.addAll(list1);
		 list2.add(new Driver(31, "M", 2));
		 
		 List<Driver>  list3 = new ArrayList<Driver>();
		 list3.addAll(list2);
		 list3.add(new Driver(41, "M", 2));
		 
		 List<Driver>  list4 = new ArrayList<Driver> ();
		 list4.addAll(list3);
		 list4.add(new Driver(51, "M", 2));
		 
		 Object[][] data = new  Object[][] {
				 {list1, 1190.0} ,
				 {list2, 1911.0} ,
				 {list3, 2707.2} ,
				 {list4, 3675.4}
		 };
	     return Arrays.asList(data);
	}
  
	public QuoteParameterizedMultiDriverTest(List list, double result){
		 this.list = list;
		 this.result = result;
	}

	@Test
	public void testParameterizedTest() {
		assertEquals(result, Quote.getCost(list), 0.01);

		 
	}
	 
}
