package com.ntier.life.insurance;

import com.thirdparty.service.MedicalRatingService;

public class MedicalRatingFake implements MedicalRatingService {

	public String requestMedicalRating(long medicalRecordId) {
		String result = "";
		if(medicalRecordId > 10000){
			result = "EXCELLENT";
		} else if (medicalRecordId < 10000 && medicalRecordId > 5000){
			result = "GOOD";
		} else {
			result = "POOR";
		}
		return result;
	}

}
