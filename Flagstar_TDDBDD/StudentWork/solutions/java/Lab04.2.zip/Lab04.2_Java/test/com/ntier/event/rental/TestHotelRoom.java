package com.ntier.event.rental;

 
import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.is;

public class TestHotelRoom {
	
	 
	private HotelRoom hotelRoom;
	
	
	@Before
	public void setUp(){
 		hotelRoom = new HotelRoom(100, false);
	}
	 
	@Test
	public void testHotelRoom(){
		 assertNotNull(hotelRoom);
		 assertThat(hotelRoom.toString(),is("100 false"));
	}

}
