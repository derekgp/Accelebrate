package com.ntier.insurance;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;


public class QuoteTest {
	 
	private Driver driver;
	@Before
	public void setUp(){
		driver = new Driver(24, "M", 2);
	}
	@Test
	public void baseCostTestDriverMale(){
		assertEquals(540.00, Quote.getCost(driver), 0.01);
		driver.setAge(25);
		assertEquals(650.00, Quote.getCost(driver), 0.01);
		driver.setAge(31);
		assertEquals(760.00, Quote.getCost(driver), 0.01);
		driver.setAge(41);
		assertEquals(870.00, Quote.getCost(driver), 0.01);
		driver.setAge(51);
		assertEquals(1090.00, Quote.getCost(driver), 0.01);
		
	}
	@Test
	public void baseCostTestDriverFeMale(){
		driver.setGender("F");
		assertEquals(490.00, Quote.getCost(driver), 0.01);
		driver.setAge(25);
		assertEquals(590.00, Quote.getCost(driver), 0.01);
		driver.setAge(31);
		assertEquals(690.00, Quote.getCost(driver), 0.01);
		driver.setAge(41);
		assertEquals(790.00, Quote.getCost(driver), 0.01);
		driver.setAge(51);
		assertEquals(990.00, Quote.getCost(driver), 0.01);
		
	} 
}
