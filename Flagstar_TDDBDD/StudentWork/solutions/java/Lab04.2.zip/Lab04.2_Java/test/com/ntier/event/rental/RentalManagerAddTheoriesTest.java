package com.ntier.event.rental;

import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.matchers.JUnitMatchers.hasItem;

@RunWith(value=Theories.class)
public class RentalManagerAddTheoriesTest {


	@DataPoint   public static RentalCar c1 =  new RentalCar(6,"Fiat", "500");
    @DataPoint   public static RentalCar c2 =  new RentalCar(6,"Honda", "Civic");


    @Theory
	public void testTheory(RentalCar rc) {
		RentalManager manager = new RentalManager();
		manager.addRentalCar(rc.getMake(), rc.getModel());
        assertThat(manager.getRentalCars(), hasItem(rc));

	}

	 
}
