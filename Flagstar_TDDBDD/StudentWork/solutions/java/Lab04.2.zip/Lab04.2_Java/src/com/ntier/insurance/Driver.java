package com.ntier.insurance;

public class Driver {
	
	private int age;
	private String gender;
	private int yearsDrivingExperience;

    Driver(){}

	 Driver(int age, String gender, int yearsDrivingExperience) {
		this.setAge(age);
		this.setGender(gender);
		this.setYearsDrivingExperience(yearsDrivingExperience);
	}

	int getAge() {
		return age;
	}

	void setAge(int age) {
		this.age = age;
	}

	String getGender() {
		return gender;
	}

	void setGender(String gender) {
		this.gender = gender;
	}

	int getYearsDrivingExperience() {
		return yearsDrivingExperience;
	}

	void setYearsDrivingExperience(int yearsDrivingExperience) {
		this.yearsDrivingExperience = yearsDrivingExperience;
	}

}
