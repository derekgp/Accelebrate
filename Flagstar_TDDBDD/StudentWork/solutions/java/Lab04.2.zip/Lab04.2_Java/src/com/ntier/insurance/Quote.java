package com.ntier.insurance;

import java.util.Collection;

public class Quote {

	public static double getCost(Driver driver) {
		// TODO Auto-generated method stub
		double cost =  getBaseCost(driver.getAge());
		if (driver.getGender().trim().equalsIgnoreCase("M")) {
			cost = 1.1 * cost;
		}
		// Note - experience discount applied after gender adjustment
		return cost - (5 * driver.getYearsDrivingExperience());
	}
	
	private static double getBaseCost(int age) {
		double baseCost = 0.0;

		if (age < 25) {
			baseCost = 500;
		} else if (age <= 30) {
			baseCost = 600;
		} else if (age <= 40) {
			baseCost = 700;
		} else if (age <= 50) {
			baseCost = 800;
		} else {
			baseCost = 1000;
		}
		return baseCost;
	}

	public static double getCost(Collection<Driver> drivers) {
		double cost = 0.0;
		for (Driver driver : drivers) {
			cost += getCost(driver);
		}
		// multiple driver discount (2% off total for each driver over 2nd one)
	    int driverCount = drivers.size();
	    if (driverCount > 2)
	    {
	      int discountDriverCount = driverCount - 2;
	      double discount = .02 * discountDriverCount;
	      cost = (1 - discount) * cost;
	    }
	    
		return cost;
	}
  

}
