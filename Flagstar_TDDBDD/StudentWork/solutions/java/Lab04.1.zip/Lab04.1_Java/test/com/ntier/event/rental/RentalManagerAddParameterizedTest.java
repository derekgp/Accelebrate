package com.ntier.event.rental;

 
import static org.junit.Assert.assertThat;
import static org.junit.matchers.JUnitMatchers.hasItem;

import java.util.Arrays;
import java.util.Collection;

 
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(value= Parameterized.class)
public class RentalManagerAddParameterizedTest {
    private long id;
	private String make;
	private String model;
	
	@Parameters
	public static Collection<Object[]> parameters(){
		 Object[][] data = new  Object[][] {
				 {6,"Fiat", "500"},
				 {6,"Kia", "Rio"},		 
		 };
		 return Arrays.asList(data); 
	}
  
	public RentalManagerAddParameterizedTest(long id, String make, String model){
		 this.id = id;
		 this.make = make;
		 this.model = model;
	}

	@Test
	public void testParameterizedTest() {
		RentalManager manager = new RentalManager();
        RentalCar c = new RentalCar(0, make, model) ;
		manager.addRentalCar(make, model);
        assertThat(manager.getRentalCars(), hasItem(c));
	}
	 
}
