package com.ntier.insurance;

/**
 * Created by IntelliJ IDEA.
 * User: DerekParsons
 * Date: 2/20/13
 * Time: 12:44 PM
 * To change this template use File | Settings | File Templates.
 */
public class DriverData {
    private Driver driver;
    private double premium;

    public DriverData(Driver driver, double expected) {
             this.driver = driver;
             this.premium = expected;
    }

	public Driver getDriver() {
		return driver;
	}

	public double getPremium() {
		return premium;
	}

   
}
