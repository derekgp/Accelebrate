package com.ntier.life.insurance;

import org.mockito.Mockito;

import com.thirdparty.service.MedicalRatingService;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class LifeQuoterStepDefinition {
	private static Insurable insured;
	private static LifeQuote quote;
	private static MedicalRatingService service;
	
	@Given("^I am a (\\d+) year old \"([^\"]*)\"$")
	public void I_am_a_year_old(int age, String gender) {
		insured = new Insurable();
		insured.setAge(age);
		insured.setGender(gender);
 		quote = new LifeQuote(insured);		
		 service =  Mockito.mock(MedicalRatingService.class);
		 Mockito.when(service.requestMedicalRating(10001)).thenReturn("EXCELLENT");
		 Mockito. when(service.requestMedicalRating(8001)).thenReturn("GOOD");
		 Mockito.when(service.requestMedicalRating(7005)).thenReturn("GOOD");
		 Mockito.when(service.requestMedicalRating(1001)).thenReturn("POOR");
		 quote.setMedRatingService(service);
	}

	@When("^I have a  medicalId of (\\d+)$")
	public void I_have_a_medicalId_of(int arg1) {
	    insured.setMedicalId(arg1);
	}

	@Then("^my premium will be (\\d+).(\\d+)$")
	public void my_premium_will_be(double arg1, double arg2) {
	    double expected = arg1 + (arg2/100);
		double actual = quote.getLifeQuote();
	    Assert.assertEquals(expected, actual, 0.01);
	}
}
