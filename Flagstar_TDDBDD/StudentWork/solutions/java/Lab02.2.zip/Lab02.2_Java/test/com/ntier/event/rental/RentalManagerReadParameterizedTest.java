package com.ntier.event.rental;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import static org.junit.matchers.JUnitMatchers.hasItem;
import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.is;
 
@RunWith(value= Parameterized.class)
public class RentalManagerReadParameterizedTest {
	
	private long id; 
	private String make;
	private String model;
	
	@Parameters
	public static Collection<Object[]> parameters(){
		 Object[][] data = new  Object[][] {
				 {1, "Toyota", "Matrix"},
				 {2, "Honda", "Civic"},
				 {3, "Nissan", "Quest"},
				 {4, "Ford", "Explorer"},
				 {5, "Mazda", "Mazda3"} 		 
		 };
		 return Arrays.asList(data); 
	}
  
	public RentalManagerReadParameterizedTest(long id, String make, String model){
		 this.id = id;
		 this.make = make;
		 this.model = model;
	}
	
	@Test
	public void testParameterizedTest() {
		RentalManager manager = new RentalManager();
		RentalCar car = manager.getRentalCar(id);
		assertThat(car != null, is (true));
		assertThat(manager.getRentalCars(), hasItem(car));
	}
	 
}
