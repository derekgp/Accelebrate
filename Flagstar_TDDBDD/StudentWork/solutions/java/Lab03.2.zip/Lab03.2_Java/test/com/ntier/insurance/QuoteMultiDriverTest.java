package com.ntier.insurance;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;


public class QuoteMultiDriverTest {
	 
	private Driver driver1;
	private Driver driver2;
	private Collection<Driver> drivers;
	@Before
	public void setUp(){
		driver1 = new Driver(24, "M", 2);
		driver2 = new Driver(25, "M", 2);
		
		drivers = new ArrayList<Driver>();
		drivers.add(driver1);
		
		drivers.add(driver2);
	}
	 
	@Test
	public void baseCostTestDriverFeMale(){
		 assertEquals(1190.0, Quote.getCost(drivers), 0.01);
		 drivers.add(new Driver(31,"M", 2));
		 assertEquals(1911.0, Quote.getCost(drivers), 0.01);
		 drivers.add(new Driver(41,"M", 2));
		 assertEquals(2707.2, Quote.getCost(drivers), 0.01);
		 drivers.add(new Driver(51,"M", 2));
		 assertEquals(3675.4, Quote.getCost(drivers), 0.01);
	} 
}
