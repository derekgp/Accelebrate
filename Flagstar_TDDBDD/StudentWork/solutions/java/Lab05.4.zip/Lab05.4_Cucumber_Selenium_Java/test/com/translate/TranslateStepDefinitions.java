package com.translate;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
  
public class TranslateStepDefinitions {
	private ChromeDriver driver;
 
	@Given("^WebDriver is initialized \"([^\"]*)\"$")
	public void WebDriver_is_initialized(String arg1) {
		System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(arg1);
	}

	@When("^a user enters \"([^\"]*)\" in the searchbox \"([^\"]*)\"$")
	public void a_user_enters_in_the_searchbox(String arg1, String arg2) {
		WebElement element = driver.findElement(By.name(arg2));
		element.sendKeys(arg1);
		element.submit();
	}

	@Then("^the url is \"([^\"]*)\"$")
	public void the_url_is(String arg1) {
		 System.out.println(driver.getCurrentUrl());
		 Assert.assertTrue(driver.getCurrentUrl().contains(arg1));
		 driver.quit();
	}

 
}
