package com.ntier.event.rental;

import org.junit.Assert;
import org.junit.Assume;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import static org.hamcrest.CoreMatchers.any;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.matchers.JUnitMatchers.hasItem;
import static org.junit.Assert.*;

public class TestRentalManager {
	
	private RentalManager manager;
	
	@Before
	public void setUp(){
		manager = new RentalManager();
	}
	
	@Test
	public void testRentalCars(){
		 assertThat(manager.getRentalCars().size(),is(5));
	}
	
	@Test
	public void testHotelRooms(){
		assertThat(manager.getHotelRooms().size(), is(4));
	}
	
	@Test
	public void testGetCar(){
		 assertNotNull(manager.getRentalCar(2));
		 assertThat(manager.getRentalCar(2).toString(), is("2 Honda Civic"));	
	}
 
	@Test
	public void testGetCarsByMake(){
		 assertThat(manager.getRentalCarByMake("a").size(), is(4));
		 assertThat(manager.getRentalCarByMake("x").size(), is(0));
 		
	}
	 
	@Test
	public void testGetCarsHasItem(){
		 RentalCar car = new RentalCar(1L, "Toyota", "Matrix");
		 assertThat(manager.getRentalCars(), hasItem(car));
	}
	
	@Test
	public void testAddCar(){
		 RentalCar car = new RentalCar(99L, "Test_Make","Test_Model");
		 assertThat(manager.getRentalCars(), not(hasItem(car)));
		 manager.addRentalCar(car);
		 assertThat(manager.getRentalCars(), hasItem(car)); 
	}
	
	@Test
	public void testdisplayCars(){
		Assume.assumeTrue(5 < 9);
		Assert.assertEquals(manager.getRentalCars().size(),manager.displayCars());
		RentalCar rentalCar1 = new RentalCar(21, "Ford", "Anglia");
		RentalCar rentalCar2 = new RentalCar(22, "Ford", "Anglia");
		 
		
	}
	
	@Test
	public void testHotelRoomsHasItem(){
		 assertThat(manager.getHotelRooms(), hasItem(new HotelRoom(12, true)));
	}
	
	@Test
	public void testdisplayHotelRooms(){
		RentalManager m = null;
 		Assume.assumeThat(m != null, is(true));
 		Assert.assertEquals(m.getHotelRooms().size(),is(100));
	    
 		 
	}
 
	public static void main(String[] args) {
		Result result = JUnitCore.runClasses(TestRentalManager.class);
		System.out.printf("run count %2d %n",result.getRunCount());
		System.out.printf("ignore count %2d %n", result.getIgnoreCount());
		System.out.printf("fail count %2d %n", result.getFailureCount());
		System.out.println("success " + result.wasSuccessful());
		System.out.printf("result time long %2d %n", result.getRunTime());
		for (Failure failure : result.getFailures()) {
			System.out.println(failure.toString());
		}
	}
}
