package com.ntier.insurance;

public class DriverData {
	
	private Driver driver;
	private double premium;

	public DriverData(Driver driver, double i) {
		this.driver = driver;
		this.premium = i;
	}

	public Driver getDriver() {
		return driver;
	}

	public double getPremium() {
		return premium;
	}

}
