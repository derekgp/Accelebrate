package com.ntier.insurance;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(value= Parameterized.class)
public class QuoteParameterizedTest {
	
	/*
	 * The �Parameterized Test� means vary parameter value for unit test. 
	 * In JUnit, both @RunWith and @Parameter annotation are use to provide 
	 * parameter value for unit test, @Parameters have to return List[], 
	 * and the parameter will pass into class constructor as argument.
	 */
	
	private int age;
	private String gender;
	private int yearsDrivingExperience;
	private double result; 
	
	@Parameters
	public static Collection<Object[]> parameters(){
		 Object[][] data = new  Object[][] {
				 {24, "M", 2, 540},
				 {25, "M", 2, 650}, 
				 {31, "M", 2, 760},
				 {41, "M", 2, 870},
				 {51, "M", 2, 1090},
				 {24, "F", 2, 490},
				 {25, "F", 2, 590}, 
				 {31, "F", 2, 690},
				 {41, "F", 2, 790},
				 {51, "F", 2, 990},
				 
		 };
	     return Arrays.asList(data);
	}
  
	public QuoteParameterizedTest(int age, String gender,int yearsDrivingExperience, double result){
		 this.age = age;
		 this.gender = gender;
		 this.yearsDrivingExperience = yearsDrivingExperience;
		 this.result = result;
	}

	@Test
	public void testParameterizedTest() {
		 Driver driver = new Driver(age, gender, yearsDrivingExperience);
		 assertEquals(result, Quote.getCost(driver), 0.01);

		 
	}
	 
}
