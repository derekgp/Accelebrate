package com.ntier.event.rental;

 
import org.junit.AfterClass;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

  
import static org.junit.Assert.assertThat;
import static org.junit.matchers.JUnitMatchers.hasItem;

@RunWith(value=Theories.class)
public class RentalManagerAddTheoriesTestThree {
     @DataPoints
   	public static RentalCar[] parameters(){
   		 return  new RentalCar[]  { 
                    new RentalCar(0L,"Fiat", "500"),
                    new RentalCar(0L,"Ford", "Fiesta"),
                    new RentalCar(0L,"Toyota", "Yaris"),

   		 };
   	}

    
    private static int count = 0;

	@Theory
	public void testTheory(RentalCar rc) {
		RentalManager manager = new RentalManager();
       	manager.addRentalCar(rc.getMake(), rc.getModel());
        assertThat(manager.getRentalCars(), hasItem(rc));
        count++;
	}
	
	@AfterClass
	public static void end(){
		System.out.println("We ran " + count + " instances");
	}
	 
}
