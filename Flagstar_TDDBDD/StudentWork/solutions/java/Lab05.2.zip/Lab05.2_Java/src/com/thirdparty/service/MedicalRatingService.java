package com.thirdparty.service;

public interface MedicalRatingService {
	
	public String requestMedicalRating(long medicalRecordId);

}
