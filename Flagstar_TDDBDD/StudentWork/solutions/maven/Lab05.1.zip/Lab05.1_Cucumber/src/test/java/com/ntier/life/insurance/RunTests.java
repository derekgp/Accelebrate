package com.ntier.life.insurance;

import org.junit.runner.RunWith;
 
import cucumber.junit.Cucumber;


@RunWith(Cucumber.class)

public class RunTests {

}
