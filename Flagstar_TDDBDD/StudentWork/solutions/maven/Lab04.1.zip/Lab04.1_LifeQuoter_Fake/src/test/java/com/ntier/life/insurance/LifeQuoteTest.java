package com.ntier.life.insurance;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
 
import com.thirdparty.service.MedicalRatingService;

public class LifeQuoteTest {

	private Insurable insured;
	private LifeQuote quote;

	@Before
	public void setUp() throws Exception {
		insured = new Insurable();
		insured.setAge(31);
		insured.setGender("M");
		insured.setMedicalId(10001);        
		quote = new LifeQuote(insured);	
		quote.setMedRatingService(new MedicalRatingFake());
//		quote.setMedRatingService(new MedicalRatingService(){
//			public String requestMedicalRating(long medicalRecordId) {
//				String result = "";
//				if(medicalRecordId > 10000){
//					result = "EXCELLENT";
//				} else if (medicalRecordId < 10000 && medicalRecordId > 5000){
//					result = "GOOD";
//				} else {
//					result = "POOR";
//				}
//				return result;
//			}
//			
//		});

	}

	 @Test
	 public void testMale30To39EXCELLENT(){
	 double expected = 25.0;
	 expected *= 1.15;
	 expected *= 1.05;
	 assertEquals(expected, quote.getLifeQuote(),.001);
	 }





		
	 @Test
	 public void testFemale50To59GOOD(){
	 insured = new Insurable();
	 insured.setAge(51);
	 insured.setGender("F");
	 insured.setMedicalId(8001);
			
	 quote = new LifeQuote(insured);
	 quote.setMedRatingService(new MedicalRatingFake());	
	 double expected = 35;
	 expected *= 1.5;

	 assertEquals(expected,quote.getLifeQuote(),.001);
			
	 }











	@Test
	public void testcalcMedicalRatingAmount() throws Exception {
		
		MedicalRatingService mrs = quote.getMedRatingService();

		assertEquals("EXCELLENT", mrs.requestMedicalRating(10009));
		assertEquals("GOOD", mrs.requestMedicalRating(7005));
		assertEquals("POOR", mrs.requestMedicalRating(1001));
	}

	
}
