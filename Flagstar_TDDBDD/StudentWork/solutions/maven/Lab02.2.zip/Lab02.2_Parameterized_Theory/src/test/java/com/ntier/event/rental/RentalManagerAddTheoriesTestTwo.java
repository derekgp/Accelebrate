package com.ntier.event.rental;

 
import org.junit.AfterClass;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;
import static org.junit.matchers.JUnitMatchers.hasItem;

@RunWith(value=Theories.class)
public class RentalManagerAddTheoriesTestTwo {


	@DataPoint   public static RentalCar c1 =  new RentalCar(6L,"Fiat", "500");
    @DataPoint   public static RentalCar c2 =  new RentalCar(6L,"Honda", "Civic");
    @DataPoint   public static Integer day1 = new Integer(2);
    @DataPoint   public static Integer day2 = new Integer(3);
    
    private static int count = 0;

	@Theory
	public void testTheory(RentalCar rc, Integer days) {
		RentalManager manager = new RentalManager();
        double result = rc.getID() * days;
        assertThat(result, is(not(0.0)));
		manager.addRentalCar(rc.getMake(), rc.getModel());
        assertThat(manager.getRentalCars(), hasItem(rc));
        count++;
	}
	
	@AfterClass
	public static void end(){
		System.out.println("We ran " + count + " instances");
	}
	 
}
