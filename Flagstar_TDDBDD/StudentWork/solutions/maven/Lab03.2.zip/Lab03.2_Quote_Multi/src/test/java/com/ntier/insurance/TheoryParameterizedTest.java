package com.ntier.insurance;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.Assert.assertEquals;

@RunWith(value=Theories.class)
public class TheoryParameterizedTest {



	@DataPoints
	public static DriverData[] parameters(){
		 return new  DriverData[]  {
				 new DriverData(new Driver(24, "M", 2), 540),
                 new DriverData(new Driver(25, "M", 2), 650),
                 new DriverData(new Driver(31, "M", 2), 760)
		 };

	}
 	@Theory   
	public void testParameterizedTest(DriverData data) {
		assertEquals(data.getPremium(), Quote.getCost(data.getDriver()), 0.01);
	}
	 
}
