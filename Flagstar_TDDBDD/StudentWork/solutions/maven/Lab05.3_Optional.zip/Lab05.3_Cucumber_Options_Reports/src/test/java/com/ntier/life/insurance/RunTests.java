package com.ntier.life.insurance;

import org.junit.AfterClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.github.mkolisnyk.cucumber.reporting.CucumberResultsOverview;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(format={"pretty","json:target/test-report.json"}, 
features="src/test/java/features", 
monochrome=true)
public class RunTests {
	
	
 
}
