package com.ntier.util;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class TestCalculator {
	
	private Calculator calculator;
	private double x;
	private double y;
	
	@Before
	public void setUp(){
		 calculator = new Calculator();
		 x = 2.5;
		 y = 3.5;
	}
	

	@Test
	public void testAdd() {
		assertEquals(6,calculator.add(x, y), 0.01);
	}

	@Test
	public void testSubtract() {
		assertEquals(-1,calculator.subtract(x, y), 0.01);
	}

	@Test
	public void testMultiply() {
		assertEquals(8.75,calculator.multiply(x, y), 0.01);
	}

	@Test
	public void testDivide() {
		assertEquals(0.71,calculator.divide(x, y), 0.01);
        assertEquals(Double.POSITIVE_INFINITY,calculator.divide(x, 0), 0.01);
	}

	@Test
	public void testIntegerDivide() {
		int a = 10;
		int b = 2;
		assertEquals(5,calculator.integerDivide(a,b));
		try{
		    calculator.integerDivide(10, 0);
		    fail("We should not be here");
		} catch (Exception e){
			assertEquals("/ by zero", e.getMessage());
		}
	}

	@Test
	public void testStringLength() {
		assertEquals(5, calculator.stringLength("JUnit"));
		Assert.assertNotSame(6, calculator.stringLength("JUnit"));
	}

	@Test
	public void testNumberCompare() {
		Double a = new Double(x);
		Double b = new Double(y);
		assertEquals(-1,calculator.numberCompare(a,b));
		assertEquals(0,calculator.numberCompare(a,a));
		try{
			assertEquals(0,calculator.numberCompare(a,null));
			fail("Should not be here");
		} catch (Exception e){
			assertEquals(null,e.getMessage());
		}
	}

}
