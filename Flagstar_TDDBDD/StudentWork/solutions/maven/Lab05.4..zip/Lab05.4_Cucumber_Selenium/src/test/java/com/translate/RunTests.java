package com.translate;

import org.junit.runner.RunWith;

import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
import cucumber.junit.Cucumber;
import cucumber.runtime.PendingException;


@RunWith(Cucumber.class)

public class RunTests {


}
