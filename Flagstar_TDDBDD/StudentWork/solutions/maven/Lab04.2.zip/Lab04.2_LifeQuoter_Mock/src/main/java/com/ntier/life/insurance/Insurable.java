package com.ntier.life.insurance;

public class Insurable {

	private int age;
	private String gender;
	private long medicalId;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public long getMedicalId() {
		return medicalId;
	}

	public void setMedicalId(long medicalId) {
		this.medicalId = medicalId;
	}

}
