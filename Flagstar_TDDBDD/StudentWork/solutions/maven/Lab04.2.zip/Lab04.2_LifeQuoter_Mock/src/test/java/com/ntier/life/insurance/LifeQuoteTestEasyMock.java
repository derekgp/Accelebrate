package com.ntier.life.insurance;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.easymock.EasyMock;
import org.junit.*;

import com.thirdparty.service.MedicalRatingService;

public class LifeQuoteTestEasyMock {

	private static Insurable insured;
	private static LifeQuote quote;
	private static MedicalRatingService service;

	@BeforeClass
	public static void setUp() throws Exception {
		insured = new Insurable();
		insured.setAge(31);
		insured.setGender("M");
		insured.setMedicalId(10001);        
		quote = new LifeQuote(insured);		
		service = EasyMock.createMock(MedicalRatingService.class);
		EasyMock.expect(service.requestMedicalRating(10001)).andReturn("EXCELLENT");
		EasyMock.expect(service.requestMedicalRating(8001)).andReturn("GOOD").anyTimes();
		EasyMock.expect(service.requestMedicalRating(7005)).andReturn("GOOD");
		EasyMock.expect(service.requestMedicalRating(1001)).andReturn("POOR");
		EasyMock.replay(service);
		quote.setMedRatingService(service);
	}

	@Test
	public void testMale30To39EXCELLENT() {
		double expected = 25.0;
		expected *= 1.15;
		expected *= 1.05;
		assertEquals(expected, quote.getLifeQuote(), .001);
	}

	 @Test
	public void testFemale50To59GOOD() {
		insured = new Insurable();
		insured.setAge(51);
		insured.setGender("F");
		insured.setMedicalId(8001);

		quote = new LifeQuote(insured);
		quote.setMedRatingService(service);
		double expected = 35;
		expected *= 1.5;

		assertEquals(expected, quote.getLifeQuote(), .001);
        /*
        Reset Mock
         */
        EasyMock.reset(service);
        EasyMock.expect(service.requestMedicalRating(8009)).andReturn("POOR");
        insured.setMedicalId(8009);
        EasyMock.replay(service);
        assertEquals(68.25, quote.getLifeQuote(), .001);

         /*
        Reset Mock
         */
        EasyMock.reset(service);
        EasyMock.expect(service.requestMedicalRating(8009)).andReturn("GOOD");
        insured.setMedicalId(8009);
        EasyMock.replay(service);
        assertEquals(52.5, quote.getLifeQuote(), .001);
	}


	
	@AfterClass
	public static void checkCalls(){
		 EasyMock.verify(service);
	}

}
