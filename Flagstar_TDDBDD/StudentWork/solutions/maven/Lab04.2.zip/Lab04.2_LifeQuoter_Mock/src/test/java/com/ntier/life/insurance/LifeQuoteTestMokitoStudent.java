package com.ntier.life.insurance;

import com.thirdparty.service.MedicalRatingService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;
@RunWith(MockitoJUnitRunner.class)
public class LifeQuoteTestMokitoStudent {
    @Mock
	private static Insurable insured;
	private static LifeQuote quote;
    @Mock
	private  MedicalRatingService service;  //automatic initializaiton of the mock

	@Test
	public void testMedicalRatingService() throws Exception {
		 
		when(insured.getMedicalId()).thenReturn(10001L);
		when(insured.getAge()).thenReturn(31);
		when(insured.getGender()).thenReturn("M");
		quote = new LifeQuote(insured);
 		when(service.requestMedicalRating(10001)).thenReturn("EXCELLENT");
		quote.setMedRatingService(service);
 
        assertEquals(30.18, quote.getLifeQuote(), .01);
        verify(service).requestMedicalRating(10001);

	}
	


}
