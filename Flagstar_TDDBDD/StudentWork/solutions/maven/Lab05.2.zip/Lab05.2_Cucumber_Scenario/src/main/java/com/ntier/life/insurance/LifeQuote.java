package com.ntier.life.insurance;

import java.util.HashMap;
import java.util.Map;

import com.thirdparty.service.MedicalRatingService;

public class LifeQuote {
	
	private Insurable insured;
	private static Map<String, Double> baseCost;
	private MedicalRatingService medRatingService;

	LifeQuote(Insurable insured) {
		this.insured = insured;
	}

	double getLifeQuote() {
		double totalRate = -1.0;
		totalRate = this.calcBaseCost();
		if (insured.getGender().equals("M")) {
			totalRate = totalRate * 1.15;
		}
	 	totalRate *= (1 + this.calcMedicalRatingAmount());
		return totalRate;

	}

	private double calcBaseCost() {
		String baseCostKey = null;
		int insuredAge = insured.getAge();
		if (insuredAge < 30) {
			baseCostKey = "29";
		} else if (insuredAge < 40) {
			baseCostKey = "39";
		} else if (insuredAge < 50) {
			baseCostKey = "49";
		} else if (insuredAge < 60){
			baseCostKey = "59";
		}
	 
		return baseCost.get(baseCostKey);
	}

	private double calcMedicalRatingAmount() {
		String medicalRating = null;
		double medicalRatingAmount = 0.0;
      	medicalRating = medRatingService.requestMedicalRating(insured.getMedicalId());

		if (medicalRating.equals("EXCELLENT")) {
			medicalRatingAmount = .05;
		} else if (medicalRating.equals("GOOD")) {
			medicalRatingAmount = .5;
		} else {
			medicalRatingAmount = .95;
		}

		return medicalRatingAmount;
	}
	
	

	public void setMedRatingService(MedicalRatingService medRatingService) {
		this.medRatingService = medRatingService;
	}



	public MedicalRatingService getMedRatingService() {
		return medRatingService;
	}



	static {
		baseCost = new HashMap<String, Double>();
		baseCost.put("29", new Double(20));
		baseCost.put("39", new Double(25));
		baseCost.put("49", new Double(30));
		baseCost.put("59", new Double(35));

	}

}
