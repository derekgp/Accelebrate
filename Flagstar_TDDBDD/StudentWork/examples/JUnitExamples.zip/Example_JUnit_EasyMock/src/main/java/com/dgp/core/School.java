package com.dgp.core;

/**
 * Created by IntelliJ IDEA.
 * User: DerekParsons
 * Date: 2/21/13
 * Time: 9:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class School {

    private Student student;

    public String wakeUp(String s){
    	 //student.register();
        //System.out.println(student.getClass().getName());
    	student.close();
    	String st  = student.status(s) ;
          
         return st;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
}
