package com.easyMock;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.dgp.core.School;
import com.dgp.core.Student;

import static junit.framework.Assert.assertEquals;

 
public class StudentEasyMock {

	Student student;

	@Before
	public void setUp() {
		student = EasyMock.createMock(Student.class);
		// Set Expectations
		EasyMock.expect(student.status("Monday")).andReturn("Active");
		 student.close();
		// Replay
		EasyMock.replay(student);
	}

	@Test
	public void testStudent() {
		School s = new School();
		// Dependency Inject
		s.setStudent(student);
		assertEquals("Active", s.wakeUp("Monday"));
		 //EasyMock.verify(student);
	}

}
