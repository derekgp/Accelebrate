package com.easyMock;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.dgp.core.School;
import com.dgp.core.Student;

import static junit.framework.Assert.assertEquals;

 
public class ResetTest {

	Student mock;
	@Before  
   public void setUp(){
	      mock = EasyMock.createMock(Student.class);
         EasyMock.expect(mock.status("Active")).andReturn("Monday");
         EasyMock.replay(mock);
	}
    @Test
    public void testStudent(){
    
       School s = new School();
        //Dependency Inject
       s.setStudent(mock);
       assertEquals("Monday", mock.status("Active"));
       
        //verify
       EasyMock.verify(mock);
 
       EasyMock.reset(mock);
       EasyMock.expect(mock.status("Tuesday")).andReturn("Sleeping");
       
       EasyMock.replay(mock);
       assertEquals("Sleeping", mock.status("Tuesday"));
       //verify
       EasyMock.verify(mock);

    }




}
