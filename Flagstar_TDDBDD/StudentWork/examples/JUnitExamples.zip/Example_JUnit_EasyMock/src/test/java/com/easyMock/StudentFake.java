package com.easyMock;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.dgp.core.School;
import com.dgp.core.Student;

import static junit.framework.Assert.assertEquals;

 
public class StudentFake {

	private Student student;

	@Before
	public void setUp() {
		student = new Student() {

			public String status(String day) {
				String result = "";
				if (day.equals("Monday")) {
					result = "Active";
				}
				return result;
			}

			public void close() {
				// TODO Auto-generated method stub
				
			}
		};
	}

	@Test
	public void testStudent() {
		School s = new School();
		// Dependency Inject
		s.setStudent(student);
		assertEquals("Active", s.wakeUp("Monday"));
		 
	}

}
