package com.mokito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.mockito.MockitoAnnotations;

import com.dgp.core.Car;

 
public class MokitoAnnotationTest {

	@SuppressWarnings("deprecation")
	@MockitoAnnotations.Mock
	private Car mockCar;

	@Test
	public void testMockDirectly() {
		MockitoAnnotations.initMocks(this);
		mockCar = mock(Car.class);
		when(mockCar.getMake()).thenReturn("Morris");
		when(mockCar.getCost()).thenReturn(1000.00);
		assertEquals("Morris", mockCar.getMake());
		assertEquals(1000.00, mockCar.getCost(), 0.01);
		verify(mockCar).getMake();
		verify(mockCar).getCost();
	}

}
