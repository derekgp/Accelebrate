package com.mokito;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.dgp.core.School;
import com.dgp.core.Student;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

 
public class MockitoStudentTest {

	Student student;

	@Before
	public void setUp() {
		student = Mockito.mock(Student.class);
		// Set Expectations
		 when(student.status("Monday")).thenReturn("Active");
		 when(student.status("Tuesday")).thenReturn("Active");
			  
		 
	}

	@Test
	public void testStudent() {
		School s = new School();
		// Dependency Inject
		s.setStudent(student);
		assertEquals("Active", s.wakeUp("Tuesday"));
		assertEquals("Active", s.wakeUp("Monday"));
		verify(student).status("Monday");
		//verify(student).close();
	}

}
