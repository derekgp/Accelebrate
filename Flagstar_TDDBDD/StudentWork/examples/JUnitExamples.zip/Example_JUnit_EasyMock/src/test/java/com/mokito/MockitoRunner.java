package com.mokito;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.dgp.core.Car;

@RunWith(MockitoJUnitRunner.class)
public class MockitoRunner {

	@Mock
	private Car mockCar;

	@Test
	public void testMockDirectly() {
		Mockito.when(mockCar.getMake()).thenReturn("Morris");
		Mockito.when(mockCar.getCost()).thenReturn(1000.00);
		assertEquals("Morris", mockCar.getMake());
		assertEquals(1000.00, mockCar.getCost(), 0.01);
		Mockito.verify(mockCar).getMake();
		Mockito.verify(mockCar).getCost();
	}

}
