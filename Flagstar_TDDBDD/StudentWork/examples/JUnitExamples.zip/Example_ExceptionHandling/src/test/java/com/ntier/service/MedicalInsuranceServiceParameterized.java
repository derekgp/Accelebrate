package com.ntier.service;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Assume;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.Theory;
import org.junit.rules.ExpectedException;
import org.junit.runner.JUnitCore;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
@RunWith(value=Parameterized.class)
public class MedicalInsuranceServiceParameterized { 
	private MedicalInsuranceService ins;
	private boolean expected;
	private String zip;
 
	public MedicalInsuranceServiceParameterized(boolean expected, String zip) {
		super();
		this.expected = expected;
		this.zip = zip;
	}
	@Before
    public void setUp(){
   	   ins = new MedicalInsuranceService();
    }
	@Parameters 
	public static Collection<Object[]> parameters(){
		Object[][] data = new  Object[][] {
				{false, "14567"},
				{true, "24567"},
				{true, "22222"},
		};
	    return Arrays.asList(data);
 
	}
	 
 	@Test
	public void testPositive(){
 	 	assertEquals(expected,ins.getMedicalPlan(zip));
	}
 	
 	public static void main(String[] args) {
	    JUnitCore core= new JUnitCore();
	    core.addListener(new MyTestListener());
	    core.run(MedicalInsuranceServiceParameterized.class);
	 }
 	 
}
