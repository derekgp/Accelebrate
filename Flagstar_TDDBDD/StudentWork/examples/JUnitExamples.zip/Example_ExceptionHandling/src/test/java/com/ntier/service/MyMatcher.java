package com.ntier.service;

import java.io.BufferedReader;
import java.io.IOException;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

public class MyMatcher extends BaseMatcher{	
	private String searchString;
	public MyMatcher(String searchString) {
		this.searchString = searchString;
	}
	public boolean matches(Object arg0) {
		BufferedReader reader = (BufferedReader) arg0; 
		String line = "";
		try {
			while((line = reader.readLine()) != null){
				if(line.contains(searchString)){
					return true;
				}
			}
		} catch (IOException e) {
 			e.printStackTrace();
		}
		return false;
	}
	public void describeTo(Description description) {
		description.appendText("File does not contain " + this.searchString); 
	}
}
