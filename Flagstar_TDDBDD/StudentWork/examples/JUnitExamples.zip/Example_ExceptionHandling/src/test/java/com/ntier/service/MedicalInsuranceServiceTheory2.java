package com.ntier.service;

import static org.junit.Assert.*;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Assume;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.rules.ExpectedException;
import org.junit.rules.TestName;
import org.junit.runner.JUnitCore;
import org.junit.runner.RunWith;

import com.ntier.service.MedicalInsuranceService;
@RunWith(value=Theories.class)
public class MedicalInsuranceServiceTheory2 { 
	@DataPoint public static DataRow d1 = new DataRow(true, "23456");
	@DataPoint public static DataRow d2 = new DataRow(true, "23496");
	@DataPoint public static DataRow d3 = new DataRow(false, "13456");
	@DataPoint public static DataRow d4 = new DataRow(true, "33456");
 
	@DataPoint public static MedicalInsuranceService ins1 = new MedicalInsuranceService();
 	@Theory
	public void testPositive(MedicalInsuranceService ins, DataRow d){
 		Assume.assumeTrue(d.getZip().startsWith("1") || d.getZip().startsWith("2"));
		assertEquals(d.isExpected(), ins.getMedicalPlan(d.getZip()));
	}
 	@Rule public ExpectedException thrown = ExpectedException.none();
 	@Theory
	public void testNegative(MedicalInsuranceService ins, DataRow d){
 		Assume.assumeFalse(d.getZip().startsWith("1") || d.getZip().startsWith("2"));
 		thrown.expect(RuntimeException.class);
		ins.getMedicalPlan(d.getZip());
	}
 	
 	public static void main(String[] args) {
	    JUnitCore core= new JUnitCore();
	    core.addListener(new MyTestListener());
	    core.run(MedicalInsuranceServiceTheory2.class);
	 }
}
