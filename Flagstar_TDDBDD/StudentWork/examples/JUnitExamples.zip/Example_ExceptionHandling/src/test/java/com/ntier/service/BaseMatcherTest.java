package com.ntier.service;

import static org.junit.Assert.assertThat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import org.junit.Test;
import static org.hamcrest.core.IsNot.*;
public class BaseMatcherTest {
	@Test
	public void testPositive() throws FileNotFoundException {
		BufferedReader reader = new BufferedReader(new FileReader(new File("text.txt")));
 		assertThat(reader, new MyMatcher("cat"));
	}	
	@Test
	public void testNegative() throws FileNotFoundException {
		BufferedReader reader = new BufferedReader(new FileReader(new File("text.txt")));
 		assertThat(reader, not(new MyMatcher("puppy")));
	}
}
