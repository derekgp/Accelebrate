package com.ntier.service;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class StringTest {

	@Test
	public void wxyz() {
		String s = "Java Rocks!";
 		assertThat(s.length(), is(11));
	}
	
	@Test
	public void abcde() {
		String s = "JUnit Rocks!";
	 	assertThat(s.length(), is(12));
	}
	
	@Test
	public void mnop() {
		String s = "Tests Rocks!";
	 	assertThat(s.length(), is(12));
	}

}
