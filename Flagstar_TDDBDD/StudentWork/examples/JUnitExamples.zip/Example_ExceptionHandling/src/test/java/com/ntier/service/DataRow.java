package com.ntier.service;

public class DataRow {
	
	private boolean expected;
	private String zip;
 
	public DataRow(boolean expected, String zip) {
		super();
		this.expected = expected;
		this.zip = zip;
	}
	public boolean isExpected() {
		return expected;
	}
	public void setExpected(boolean expected) {
		this.expected = expected;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}

}
