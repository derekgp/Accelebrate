package com.ntier.service;

import static org.junit.Assert.*;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Assume;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.rules.ExpectedException;
import org.junit.rules.TestName;
import org.junit.runner.JUnitCore;
import org.junit.runner.RunWith;

import com.ntier.service.MedicalInsuranceService;
@RunWith(value=Theories.class)
public class MedicalInsuranceServiceTheory { 
	@DataPoint public static String zip1 = "12345";
	@DataPoint public static String zip2 = "23456";
	@DataPoint public static String zip3 = "23456";
	@DataPoint public static String zip4 = "32345";
 
	@DataPoint public static MedicalInsuranceService ins1 = new MedicalInsuranceService();
 	@Theory
	public void testPositive(MedicalInsuranceService ins, String zip){
 		Assume.assumeTrue(zip.startsWith("1") || zip.startsWith("2"));
		assertTrue(ins.getMedicalPlan(zip));
	}
 	@Rule public ExpectedException thrown = ExpectedException.none();
 	@Theory
	public void testNegative(MedicalInsuranceService ins, String zip){
 		Assume.assumeFalse(zip.startsWith("1") || zip.startsWith("2"));
 		thrown.expect(RuntimeException.class);
		ins.getMedicalPlan(zip);
	}
}
