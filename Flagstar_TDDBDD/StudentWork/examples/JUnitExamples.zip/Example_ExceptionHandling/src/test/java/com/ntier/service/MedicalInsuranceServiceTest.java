package com.ntier.service;

import static org.junit.Assert.*;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import org.junit.rules.ExpectedException;
import org.junit.rules.TestName;
import org.junit.runner.JUnitCore;

import com.ntier.service.MedicalInsuranceService;

public class MedicalInsuranceServiceTest {
    private MedicalInsuranceService ins;
	@Before
    public void setUp(){
   	ins = new MedicalInsuranceService();
    }
	@Test
	public void test1() {
		try{
			ins.getMedicalPlan("44567");
			fail("We should not be here");
		}catch (Throwable e){
			assertEquals("com.ntier.service.MedicalException", e.getClass().getName() );
			assertEquals("Four is out!", e.getMessage());
		}
	}
	
	@Test(expected=RuntimeException.class)
	public void test2() {
			ins.getMedicalPlan("44567");
			fail("We should not be here");
	}
	private Logger log = Logger.getLogger(this.getClass().getName());
	@Rule  public final TestName testName = new TestName();
	@Rule public ExpectedException thrown = ExpectedException.none();
 	@Test
	public void test3() {
 		thrown.expect(MedicalException.class);
		thrown.expectMessage("Four is out!");
		ins.getMedicalPlan("44567");
		fail("We should not be here");
	} 
	@After
	public void end(){
		log.log(Level.INFO, "Test Completed '" + testName.getMethodName());
	}
	
	public static void main(String[] args) {
	    JUnitCore core= new JUnitCore();
	    core.addListener(new MyTestListener());
	    core.run(MedicalInsuranceServiceTest.class);
	 }

}
