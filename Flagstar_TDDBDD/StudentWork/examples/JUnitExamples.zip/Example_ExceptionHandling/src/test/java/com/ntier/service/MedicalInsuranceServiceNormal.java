package com.ntier.service;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Assume;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.Theory;
import org.junit.rules.ExpectedException;
import org.junit.runner.JUnitCore;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
 
public class MedicalInsuranceServiceNormal { 
	private MedicalInsuranceService ins;
	@Before
    public void setUp(){
   	   ins = new MedicalInsuranceService();
    }
 	@Test
	public void testPositive1(){
 	 	assertEquals(false,ins.getMedicalPlan("14567"));
	}
 	@Test
	public void testPositive2(){
 	 	assertEquals(true,ins.getMedicalPlan("24567"));
	}
 	@Test
	public void testPositive3(){
 	 	assertEquals(true,ins.getMedicalPlan("22222"));
	} 
}
