package com.ntier.service;

class MedicalException extends RuntimeException {
		public MedicalException(String message) {
		super(message);
		}	
}
