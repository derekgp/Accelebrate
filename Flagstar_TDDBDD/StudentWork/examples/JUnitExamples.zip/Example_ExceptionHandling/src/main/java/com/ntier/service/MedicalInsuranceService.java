package com.ntier.service;

public class MedicalInsuranceService {	
	public boolean getMedicalPlan(String zip){
 		boolean result = false;
 		switch(Integer.parseInt(zip.substring(0, 1))){
		   case 1: break; 
		   case 2: result = true; break;
		   case 3: throw new RuntimeException("Three is out!");
		   case 4: throw new MedicalException("Four is out!");
 		   default: throw new MedicalException("Over 4 is definitely out!");
		}
		return result;
	}
	
	 
}
