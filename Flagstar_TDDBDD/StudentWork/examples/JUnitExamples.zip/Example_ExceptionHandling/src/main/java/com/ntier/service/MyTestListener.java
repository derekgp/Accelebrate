package com.ntier.service;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.runner.Description;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

public class MyTestListener extends RunListener{
	private Logger log = Logger.getLogger(this.getClass().getName());
	@Override
	public void testRunStarted(Description description) throws Exception {
		log.log(Level.INFO, "Run Started:" + description.testCount());
	}

	@Override
	public void testRunFinished(Result result) throws Exception {
		log.log(Level.INFO, "run finished run count:" + result.getRunCount());
	}

	@Override
	public void testStarted(Description description) throws Exception {
		log.log(Level.INFO, "Test Started:" + description.getMethodName());

	}

	@Override
	public void testFinished(Description description) throws Exception {
		log.log(Level.INFO, "Test Finished:" + description.getMethodName());

	}

	@Override
	public void testFailure(Failure failure) throws Exception {
		log.log(Level.INFO, "Test Failed:" + failure.getMessage());

	}

	@Override
	public void testAssumptionFailure(Failure failure) {
		log.log(Level.INFO, "Test Asusmption Failed:" + failure.getMessage());
	}

}
