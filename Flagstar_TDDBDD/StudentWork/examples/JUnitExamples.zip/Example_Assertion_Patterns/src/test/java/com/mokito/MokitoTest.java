package com.mokito;

 

import org.junit.Test;
import org.mockito.MockitoAnnotations;

import com.dgp.core.Car;
import com.dgp.core.Driver;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

 
public class MokitoTest {


         private Car mockCar;

         @Test
         public void testMockDirectly(){
               mockCar =  mock(Car.class);
               when(mockCar.getMake()).thenReturn("Morris");
               when(mockCar.getCost()).thenReturn(1000.00);
               assertEquals("Morris", mockCar.getMake());
               assertEquals(1000.00, mockCar.getCost(), 0.01);
               verify(mockCar).getMake() ;
               verify(mockCar).getCost() ;
         }

         @Test
         public void testInjectedMock(){
               mockCar =  mock(Car.class);
               when(mockCar.getMake()).thenReturn("Morris");
               when(mockCar.getModel()).thenReturn("Marina");
               Driver d = new Driver();
               d.setCar(mockCar);
               assertEquals("Driving my Morris Marina 300 miles", d.move(300));
               verify(mockCar).getMake() ;
         }

         @Test
          public void testVoid(){
               mockCar =  mock(Car.class);
               mockCar.park();
               verify(mockCar).park();
          }

          @Test
          public void testFrequencyInvocation(){
               mockCar =  mock(Car.class);
               mockCar.park();
               mockCar.park();

               Driver d = new Driver();
               d.setCar(mockCar);
               d.move(300) ;
               d.move(300) ;

               verify(mockCar, times(2)).park();
               verify(mockCar, times(2)).getMake();
          }

          @Test
          public void testNoInvocation(){
               mockCar =  mock(Car.class);
               //mockCar.park();
               verify(mockCar, never()).park();


          }

}
