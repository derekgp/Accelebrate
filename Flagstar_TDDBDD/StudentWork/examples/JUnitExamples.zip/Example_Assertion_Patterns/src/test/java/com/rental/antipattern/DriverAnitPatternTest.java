package com.rental.antipattern;

import com.dgp.core.Driver;
import com.dgp.core.Policy;
 


import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;

import junit.framework.Assert;
import static org.hamcrest.CoreMatchers.any;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.*;
import static org.junit.matchers.JUnitMatchers.containsString;
import static org.junit.matchers.JUnitMatchers.either;
import static org.junit.matchers.JUnitMatchers.hasItem;

/**
 * Created by IntelliJ IDEA.
 * User: Owner
 * Date: 8/10/12
 * Time: 9:59 AM
 * To change this template use File | Settings | File Templates.
 */
public class DriverAnitPatternTest {

 
    private Driver driver;
    private Policy p1;
    private Policy p2;


    @Before
    public void setScene(){
        driver  = new Driver("ed", "Lancealot", 18, 1, "M");
        java.util.List<Policy> list = new ArrayList<Policy>();
        p1 =  new Policy(12345, "State Farm");
        p2 =  new Policy(45888, "All State");
        list.add(p1) ;
        list.add(p2) ;
        driver.setInsurancePolicies(list);
    }


    @Test
    public void testSuccessAgainstAllOdds(){
       assertThat(driver.getFirstName(),
               either(containsString("somethingIdonothave")).or(containsString("")));
       assertThat(driver.getFirstName(), is(any(String.class)));
    }

    @Test
    public void testOrderingOne(){
        assertThat(driver.getInsurancePolicies(), hasItem(p1));
        driver.getInsurancePolicies().add(new Policy(87888, "Geico"));
        assertTrue(driver.getInsurancePolicies().size() == 3);
    }

    @Test
    public void testOrderingTwoFails(){
        if(driver.getInsurancePolicies().size() == 3) {
             assertThat(driver.getInsurancePolicies(), hasItem(p1));
        } else {
            fail("Why are there not three policies in my list?");
        }
    }

    @Test
    public void testGreedyCatcherAndStranger(){
        try {
            Assert.assertTrue(driver.drinkDrive());
        }  catch(Throwable e){
           // System.out.println("Got an exception but lets keep going");
        }
        assertEquals("I am ok to drive", driver.drive());
    }

    @Test
    public void testLoudMouth(){
        java.util.List<Policy> policies = driver.getInsurancePolicies();
        for(int i=0; i<policies.size(); i++){
            Policy p = policies.get(i) ;
            assertNotNull(p);
            assertThat(p.getNumber(), is(not(100)));
            System.out.println(p.getNumber()) ;
            assertThat(p.getCompany(), is(any(String.class)));
            System.out.println(p.getCompany()) ;
        }
    }


    @Test
    public void testLocalHero(){
        String key = "java.home" ;
        if(System.getProperty(key).equals("C:\\Program Files\\Java\\jdk1.6.0_29\\jre")) {
           assertThat(driver.getFirstName(), either(containsString("mund")).or(containsString("abc")));
        }  else {
            fail("Driver is not initialized");
        }
    }



    @Test
    public void testOperatingSystemEvangelist(){
        String key = "os.name" ;
        if(System.getProperty(key).equals("Windows 7")) {
           assertThat(driver.getFirstName(), either(containsString("mund")).or(containsString("abc")));
        }  else {
            fail("Driver is not initialized");
        }
    }



    @Test
    public void testWhatDidITest(){
        String key = "os.name" ;
        if(System.getProperty(key).equals("FOOBar")) {
           assertThat(driver.getFirstName(), either(containsString("mund")).or(containsString("abc")));
        }  else {
            if(driver.getAge() < 0) {
                 assertThat(driver.getAge(), is(not(100)));
            }
        }
    }
}
