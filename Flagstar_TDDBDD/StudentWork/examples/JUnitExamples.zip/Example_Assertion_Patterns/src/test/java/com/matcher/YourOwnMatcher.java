package com.matcher;
 
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.dgp.core.Driver;
import com.dgp.core.Policy;

 
public class YourOwnMatcher {

    private Driver driver;

    @Before
    public void setScene(){
        driver  = new  Driver();
        driver.setLastName("Lancealot");
        driver.setFirstName("Edmund");
        driver.setAge(18);
        List<Policy> list = new ArrayList<Policy>();
        list.add(new Policy(12345, "State Farm")) ;
        list.add(new Policy(45888, "All State")) ;
        driver.setInsurancePolicies(list);
    }


    @Test
    public void testBasic(){
         Policy p1 = new Policy(55555, "Geico");
         Policy p2 = new Policy(88888, "Geico");
         assertEquals(p1.getCompany(), p2.getCompany()) ;
         assertFalse(p1.getNumber() == p2.getNumber()) ;
    }
    private PolicyMatcher policyMatcher(){
        return new PolicyMatcher(55555, "Geico");
    }

    @Test
      public void testPolicyOne(){
        Policy p1 = new Policy(55555, "Geico");
        Policy p2 = new Policy(88888, "Geico");
        assertThat(p1,  is(policyMatcher()));
        //assertThat(p2,  is(policyMatcher()));
        assertThat(p2,  is( not(policyMatcher())));
      }


     @Test
      public void testPolicyTwo(){
        Policy p1 = new Policy(55588, "Geico");
        Policy p2 = new Policy(88888, "Geico");
        assertThat(p1,  is( new PolicyMatcher(55555, "Geico")));
        assertThat(p2,  is( not(policyMatcher())));
      }

   


}
