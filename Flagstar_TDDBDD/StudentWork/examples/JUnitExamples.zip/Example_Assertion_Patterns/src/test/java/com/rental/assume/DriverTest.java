package com.rental.assume;

import com.dgp.core.Driver;
import com.dgp.core.Policy;

import org.junit.Assume;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;
import static org.junit.matchers.JUnitMatchers.containsString;
import static org.junit.matchers.JUnitMatchers.either;
import static org.junit.matchers.JUnitMatchers.hasItem;

/**
 * Created by IntelliJ IDEA.
 * User: DerekParsons
 * Date: 12/10/12
 * Time: 5:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class DriverTest {
	 private Driver driver;
	   private Policy p1;
	    private Policy p2;
	    
	 @Before
	    public void setScene(){
	        driver  = new Driver("ed", "Lancealot", 18, 1, "M");
	        java.util.List<Policy> list = new ArrayList<Policy>();
	        p1 =  new Policy(12345, "State Farm");
	        p2 =  new Policy(45888, "All State");
	        list.add(p1) ;
	        list.add(p2) ;
	        driver.setInsurancePolicies(list);
	    }

    @Test
    public void testUnInsuredDriver(){
        
        assertEquals(2, driver.getInsurancePolicies().size());
        
        driver.setInsurancePolicies(null);
        
        //but what if ! change the list
        Assume.assumeTrue(driver.getInsurancePolicies() != null);
        assertEquals(2, driver.getInsurancePolicies().size());
 
   
    }

    @Test(expected = RuntimeException.class)
    public void testInsuredDriver(){
        driver.drinkDrive();
        assertEquals(8, driver.getInsurancePolicies().size());
    }

    

   
}
