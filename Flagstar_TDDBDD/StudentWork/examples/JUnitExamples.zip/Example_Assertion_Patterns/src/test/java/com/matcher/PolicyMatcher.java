package com.matcher;
 
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

import com.dgp.core.Policy;
 
public class PolicyMatcher extends BaseMatcher<Policy> {
    private int pNumber;
    private String cmp;

    public PolicyMatcher(int x, String y){
          pNumber = x;
          cmp = y;
    }

    public boolean matches(Object o) {
        Policy p = (Policy) o;
        if(p.getNumber() == pNumber && p.getCompany().equalsIgnoreCase(cmp)) {
            return true ;
        } else {
            return false;
        }
    }

    public void describeTo(Description description) {
        description.appendText("Expected ").appendValue(pNumber + " whatever blah blah blah " + cmp);
    }



}
