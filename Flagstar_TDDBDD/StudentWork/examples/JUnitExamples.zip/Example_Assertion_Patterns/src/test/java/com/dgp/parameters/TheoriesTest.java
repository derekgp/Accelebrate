package com.dgp.parameters;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.dgp.core.Driver;
import com.dgp.core.QuoteEngine;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

@RunWith(value=Theories.class)
public class TheoriesTest {

    private QuoteEngine quoteEngine;


    private static int count = 0;

    public TheoriesTest(){
        System.out.println("In constructor " + count++);
    }

    @DataPoints
	public static Data[] parameters(){
		 return  new Data[]  { 
                 new Data(new Driver("ed", "Test", 7, 25, "M"), 100.35),
                 new Data(new Driver("Anne", "Again", 15, 55, "F"), 100.00),
                 new Data(new Driver("abc", "Hola", 5, 25, "M"), 100.25),

		 };
	}



    @Before
    public void setUp(){
         quoteEngine = new QuoteEngine();
    }

 
	@Theory
	public void testTheory(Data data) {
        double quote = quoteEngine.quote(data.getDriver());
        assertEquals(data.getResult(), quote, 0.01);
        System.out.println(quote) ;
		 
	}

}
