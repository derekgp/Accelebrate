package com.easyMock;

import org.easymock.EasyMock;
import org.junit.Test;

import com.dgp.core.School;
import com.dgp.core.Student;

import static junit.framework.Assert.assertEquals;

 
public class EasyTest {


    @Test
    public void testStudent(){
        //Create Mock
       Student student =  EasyMock.createMock(Student.class);
       //Set Expectations
       EasyMock.expect(student.status("Monday")).andReturn("Active");
       student.register();
        //Replay
       EasyMock.replay(student);

       School s = new School();
        //Dependency Inject
       s.setStudent(student);
       assertEquals("Active", s.wakeUp("Monday"));
       student.register();
        //verify
        EasyMock.verify(student);




       EasyMock.reset(student);
        EasyMock.expect(student.status("Tuesday")).andReturn("Sleeping");
         EasyMock.replay(student);
         assertEquals("Sleeping", s.wakeUp("Tuesday"));
       //verify
      EasyMock.verify(student);

    }




}
