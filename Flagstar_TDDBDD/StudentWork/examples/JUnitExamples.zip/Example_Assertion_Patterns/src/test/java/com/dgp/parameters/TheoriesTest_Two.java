package com.dgp.parameters;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.dgp.core.Driver;
import com.dgp.core.QuoteEngine;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

@RunWith(value=Theories.class)
public class TheoriesTest_Two {

    private QuoteEngine quoteEngine;


    private static int count = 0;

    public TheoriesTest_Two(){
        System.out.println("In constructor " + count++);
    }

    @DataPoint public static Data d1 = new Data(new Driver("ed", "Test", 7, 25, "M"), 200.7);
    @DataPoint public static Data d2 = new Data(new Driver("Anne", "Again", 15, 55, "F"), 200.00);
    @DataPoint public static Data d3 = new Data(new Driver("abc", "Hola", 5, 25, "M"), 200.5);

     @DataPoint public static int risk1 = 2;
     @DataPoint public static int risk2 = 2;
   


    @Before
    public void setUp(){
         quoteEngine = new QuoteEngine();
    }

 
	@Theory
	public void testTheory(Data data, int risk) {
        double quote = quoteEngine.quote(data.getDriver());
        assertEquals(data.getResult(), quote  * risk, 0.01);
        System.out.println(quote) ;
		 
	}

}
