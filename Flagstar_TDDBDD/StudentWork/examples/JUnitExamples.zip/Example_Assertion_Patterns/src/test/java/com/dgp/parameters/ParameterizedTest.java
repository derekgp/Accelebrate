package com.dgp.parameters;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.dgp.core.Driver;
import com.dgp.core.QuoteEngine;

@RunWith(value=Parameterized.class)
public class ParameterizedTest {
 
	private int age;
	private String gender;
	private int yearsDrivingExperience;
    private double result;
    
    private QuoteEngine quoteEngine;
	 
	
	@Parameters
	public static Collection<Object[]> parameters(){
		 Object[][] data = new  Object[][] {
				 {24, "M", 2, 115.0 },
				 {25, "M", 2, 115.62 },
                 {25, "F", 5, 105.0 },
		 };
	     return Arrays.asList(data);
	}
  
	public ParameterizedTest(int age, String gender,int yearsDrivingExperience, double result){
		 this.age = age;
		 this.gender = gender;
		 this.yearsDrivingExperience = yearsDrivingExperience;
         this.result = result;
	}

    @Before
    public void setUp(){
         quoteEngine = new QuoteEngine();
    }

	@Test
	public void testParameterizedTest() {
		Driver driver = new Driver();
	    driver.setAge(this.age);
        driver.setYearsOFExperience(this.yearsDrivingExperience);
        driver.setGender(this.gender);

        double quote = quoteEngine.quote(driver);
        assertEquals(result, quote, 0.005);
		 
	}
	 
}
