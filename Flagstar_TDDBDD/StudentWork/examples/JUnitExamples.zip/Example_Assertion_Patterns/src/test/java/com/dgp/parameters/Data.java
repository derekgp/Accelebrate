package com.dgp.parameters;

import com.dgp.core.Driver;

public class Data {
	
	private Driver driver;
	private double result;
	public Data(Driver driver, double result) {
		super();
		this.driver = driver;
		this.result = result;
	}
	public Driver getDriver() {
		return driver;
	}
	public void setDriver(Driver driver) {
		this.driver = driver;
	}
	public double getResult() {
		return result;
	}
	public void setResult(double result) {
		this.result = result;
	}
	
	

}
