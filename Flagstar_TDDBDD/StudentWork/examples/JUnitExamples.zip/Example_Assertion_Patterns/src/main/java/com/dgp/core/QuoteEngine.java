package com.dgp.core;

 
public class QuoteEngine {


    public double quote(Driver driver){
            if(driver.getGender().equals("F")) {
                return 100 + (1 * driver.getAge() / driver.getYearsOFExperience());
            } else {
                return 100 + (1.25 * driver.getAge() / driver.getYearsOFExperience());
            }

    }
}
