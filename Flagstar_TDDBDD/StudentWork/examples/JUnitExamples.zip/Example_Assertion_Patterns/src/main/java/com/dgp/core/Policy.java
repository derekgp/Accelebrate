package com.dgp.core;

/**
 * Created by IntelliJ IDEA.
 * User: Owner
 * Date: 7/6/12
 * Time: 10:20 AM
 * To change this template use File | Settings | File Templates.
 */
public class Policy {

    private int number;
    private String company;

    public Policy(int x, String y) {
        number = x;
        company = y;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Policy policy = (Policy) o;

        if (number != policy.number) return false;
        if (company != null ? !company.equals(policy.company) : policy.company != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = number;
        result = 31 * result + (company != null ? company.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Policy{" +
                "number=" + number +
                ", company='" + company + '\'' +
                '}';
    }
}
