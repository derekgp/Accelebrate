package com.dgp.core;

/**
 * Created by IntelliJ IDEA.
 * User: DerekParsons
 * Date: 2/21/13
 * Time: 9:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class School {

    private Student student;

    public String wakeUp(String s){
        //System.out.println(student.getClass().getName());
        return student.status(s) ;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
}
