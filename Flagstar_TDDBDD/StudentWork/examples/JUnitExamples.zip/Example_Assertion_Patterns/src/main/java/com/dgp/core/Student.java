package com.dgp.core;

/**
 * Created by IntelliJ IDEA.
 * User: DerekParsons
 * Date: 2/21/13
 * Time: 9:47 AM
 * To change this template use File | Settings | File Templates.
 */
public interface Student {

    String status(String day) ;

    void register();
}
