package com.dgp.core;

import java.util.List;

public class Driver {
 
	private String firstName;
	private String lastName;
    private int age;
    private int yearsOFExperience;
    private String gender;
    private Car car;
    
    private List<Policy> insurancePolicies;
 
    public Driver() {
		super();
	}

	public Driver(String firstName, String lastName, int age,
			int yearsOFExperience, String gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.yearsOFExperience = yearsOFExperience;
		this.gender = gender;
	}
 
	public List<Policy> getInsurancePolicies() {
		return insurancePolicies;
	}
 
	public void setInsurancePolicies(List<Policy> insurancePolicies) {
		this.insurancePolicies = insurancePolicies;
	}
 
	public String getFirstName() {
		return firstName;
	}

	public int getAge() {
		return age;
	}

	public int getYearsOFExperience() {
		return yearsOFExperience;
	}

	public String getGender() {
		return gender;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setYearsOFExperience(int yearsOFExperience) {
		this.yearsOFExperience = yearsOFExperience;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public boolean drinkDrive(){
        throw new RuntimeException("Caught");
    }
	
	public String drive(){
		return "I am ok to drive";
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public Object move(int i) {
		// TODO Auto-generated method stub
		return "Driving my " +  this.getCar().getMake() + " " + this.getCar().getModel() + " " + i + " miles";
	}
}
