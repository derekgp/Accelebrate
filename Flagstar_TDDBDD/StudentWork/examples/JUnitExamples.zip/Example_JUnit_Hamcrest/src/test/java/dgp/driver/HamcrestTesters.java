package dgp.driver;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.dgp.core.Driver;
import com.dgp.core.Policy;
import static org.hamcrest.CoreMatchers.any;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.matchers.JUnitMatchers.containsString;
import static org.junit.matchers.JUnitMatchers.either;
import static org.junit.matchers.JUnitMatchers.hasItem;
import static org.hamcrest.CoreMatchers.*;

public class HamcrestTesters {
	
	Driver driver;
	Policy p1, p2;
	@Before
    public void setScene(){
        driver  = new Driver("edmund", "Lancealot", 18, 1, "M");
        java.util.List<Policy> list = new ArrayList<Policy>();
        p1 =  new Policy(12345, "State Farm");
        p2 =  new Policy(45888, "All State");
        list.add(p1) ;
        list.add(p2) ;
        driver.setInsurancePolicies(list);
    }
	@Test
    public void testDriverOne(){
        assertThat(driver.getAge(), is(18));
        assertThat(driver.getAge(), is(not(17)));
        assertThat(driver.getFirstName(), 
		either(containsString("ed")).or(containsString("abc")));
    }

	@Test
	public void testDriverFour(){
	        Policy p1 = new Policy(11222, "Geico");
	        Policy p2 = new Policy(88888, "Farmers");
	        driver.getInsurancePolicies().add(p1);
	        assertThat(driver.getInsurancePolicies(), hasItem(p1));
	        assertThat(driver.getInsurancePolicies(), not(hasItem(p2)));
	}
	
	@Test
	 public void testDriverFive(){
	        Policy p1 = new Policy(11222, "Geico");
	        Policy p2 = new Policy(88888, "Farmers");
	        Policy p3 = new Policy(87788, "esurance");

	        driver.getInsurancePolicies().add(p1);
	        driver.getInsurancePolicies().add(p2);

	        assertThat(driver.getInsurancePolicies(), allOf(hasItem(p1), hasItem(p2)));
	        assertThat(driver.getInsurancePolicies(), anyOf(hasItem(p1), hasItem(p3)));
	        
	        Policy px = new Policy(11222, "Geico");
	        px = p1;
	        assertThat(px, is(sameInstance(p1)));
	}


	@Test
	public void testDriverSix(){
		assertThat(driver.getFirstName(), is(allOf(notNullValue(),equalTo("edmund"))));
		assertThat(driver.getFirstName(), 
				is(anyOf(equalTo("Derek"),equalTo("Ed"), containsString("mun"))));
		assertThat(driver.getFirstName(), is(any(String.class)));
   
	}
 
}
