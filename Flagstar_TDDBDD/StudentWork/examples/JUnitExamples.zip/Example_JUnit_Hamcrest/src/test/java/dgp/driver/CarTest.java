package dgp.driver;

import static org.junit.Assert.fail;
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;
 
import org.junit.Before;
import org.junit.Test;

import com.dgp.core.Car;

public class CarTest {
	private Car c;
	@Before
	public void setup(){
		c = new Car();
		c.setMake("Ford");
	}
	@Test
	public void test() {
		assertThat(c.getMake(), is("Ford"));
		assertThat(c.getMake(), is(not("Toyota")));
	}

}
