package com.dgp;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import junit.framework.Assert;
import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
 
public class YahooStepDefinitions {
	private WebDriver driver;

	@Given("^WebDriver is initialized \"([^\"]*)\"$")
	public void WebDriver_is_initialized(String arg1) {
		System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(arg1);

	}

	@When("^a user enters \"([^\"]*)\" in the searchbox \"([^\"]*)\"$")
	public void a_user_enters_in_the_searchbox(String arg1, String arg2) {
		WebElement element = driver.findElement(By.name(arg2));
		element.sendKeys(arg1);
		element.submit();
	}

	@Then("^the page title is \"([^\"]*)\"$")
	public void the_page_title_is(String arg1) {
		Assert.assertEquals(arg1, driver.getTitle());
	}

	@When("^a user clicks the link \"([^\"]*)\"$")
	public void a_user_clicks_the_link(String arg1) {
		driver.findElement(By.linkText(arg1)).click();

	}

	@Then("^the page text contains \"([^\"]*)\"$")
	public void the_page_text_contains(String arg1) {
		Assert.assertTrue(arg1, driver.getPageSource().contains(arg1));
		driver.quit();
	}

}
