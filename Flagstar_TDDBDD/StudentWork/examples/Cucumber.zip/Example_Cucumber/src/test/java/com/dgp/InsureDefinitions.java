package com.dgp;


 
import com.insure.core.Insured;
import com.insure.core.Quote;

import junit.framework.Assert;
import cucumber.annotation.en.And;
import cucumber.annotation.en.But;
import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
import cucumber.runtime.PendingException;
 
public class InsureDefinitions {
	private Quote quote;
	Insured insured;

	@Given("^I am a (\\d+) years old man in \"([^\"]*)\" health$")
	public void m1(int age, String health) {
		insured = new Insured(health, age);
		quote = new Quote();
		quote.setInsured(insured);
	}

	@But("^I only exercise (\\d+) times a week$")
	public void I_only_exercise_times_a_week(int arg1) {
		insured.setExerciseFrequency(arg1);
	}

	@When("^I ask for a (\\d+) year term$")
	public void m2(int years) {
		quote.setYears(years);
	}

	@Then("^my monthly premium will be (\\d+)$")
	public void m3(int balance) {
		int actual = quote.calc();
		Assert.assertEquals(balance, actual);
	}

	@And("^my status should be \"([^\"]*)\"$")
	public void I_my_status_should_be(String arg1) {
		Assert.assertEquals(arg1,quote.getStatus());
	}

}
