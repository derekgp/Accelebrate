package com.insure.core;

public class Insured {
	
	private String health;
	private int age;
	private int exerciseFrequency;
	
	public Insured(String health, int age) {
		super();
		this.health = health;
		this.age = age;
	}

	public String getHealth() {
		return health;
	}

	public int getAge() {
		return age;
	}

	public void setExerciseFrequency(int exerciseFrequency) {
		this.exerciseFrequency = exerciseFrequency;
	}

	public int getExerciseFrequency() {
		return exerciseFrequency;
	}

	 

	 

}
