package com.insure.core;

public class Quote {
	
	private Insured insured;
	private int years;

	public Insured getInsured() {
		return insured;
	}

	public void setInsured(Insured insured) {
		this.insured = insured;
	}

	public void setYears(int years) {
		this.years = years;
	}

	public int calc() {
		return  (int) (getHealthFactor() * insured.getAge()) ;
	}
	
	private double getHealthFactor(){
		double result = 1.0;
		if (insured.getHealth().equalsIgnoreCase("good")){
			result = result * 0.90;
		}
		if (insured.getExerciseFrequency() > 3){
			result = result * 0.90;
		}
		return  result;
	}

	public String getStatus() {
		String status = "rejected";
		if(calc() < 40){
			status = "approved";
		}
		return status;
	}
 
}
