package com.dgp;

 
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import junit.framework.Assert;
import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
import cucumber.runtime.PendingException;
 
 
public class BlogDefinitions {
	private WebDriver driver; 
	@Given("^WebDriver is initialized$")
	public void m1() {
		driver = new FirefoxDriver();
        driver.get("http://dgparsons.org//");

	}

	@When("^a user clicks the web services link")
	public void m2() {
		driver.findElement(By.linkText("JAX-RS")).click();
	}

	@Then("^the page title is \"([^\"]*)\" and contains text \"([^\"]*)\"$")
	public void m3(String title, String info) { 
		Assert.assertEquals(title, driver.getTitle());
		driver.getPageSource().contains(info);
		 
	}

}
