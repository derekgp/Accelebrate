package com.dgp;

public class CoffeeBar {
	private double price;
	private int qty;

	public void setPrice(double price) {
		this.price = price;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public double makeOrder() {
		return price * qty;	}

	 

	 

}
