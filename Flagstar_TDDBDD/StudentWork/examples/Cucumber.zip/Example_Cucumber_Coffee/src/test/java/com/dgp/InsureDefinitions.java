package com.dgp;

 
import junit.framework.Assert;
import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
 

public class InsureDefinitions {
	private CoffeeBar bar;

	@Given("^A store sells coffee at (\\d+).(\\d+) a cup$")
	public void A_strore_sells_coffee_at_a_cup(double arg1, double arg2) {
		bar = new CoffeeBar();
		double price = arg1 + (arg2 / 100);
		bar.setPrice(price);
	}

	@When("^I ask for (\\d+) cups$")
	public void I_ask_for_a_cup(int arg1) {
		bar.setQty(arg1);
	}
 
	
	@Then("^my bill will be \"([^\"]*)\"$")
	public void my_bill_will_be(String arg1) {
	    double expected = Double.parseDouble(arg1);
	    Assert.assertEquals(expected, bar.makeOrder(), 0.001);
	}

}
