package com.dgp;

import gherkin.formatter.model.DataTableRow;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import com.insure.core.HealthStream;
import com.insure.core.Insured;
import com.insure.core.Quote;

import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
import cucumber.runtime.PendingException;
import cucumber.table.DataTable;

public class InsureStepDefinitions {
	private Quote quote;
	private Insured insured;
	@Given("^the HealthFactors for health$")
 	public void the_HealthFactors_for_health(DataTable arg1) {
 	    // Express the Regexp above with the code you wish you had
 	    // For automatic conversion, change DataTable to List<YourType>
 		Map<String, Double> factors = new HashMap<String, Double>();
 		List<DataTableRow> list = arg1.getGherkinRows();
 		for (DataTableRow row : list) {
  			List<String> cells = row.getCells();
  			factors.put(cells.get(0), Double.parseDouble(cells.get(1)));
 		}
 		HealthStream.setHealthFactors(factors);
 	     
 	}
 
 	
 	@Given("^the HealthFactors for exercise$")
 	public void the_HealthFactors_for_exercise(List<ExerciseFactor> list) {
 		Map<Integer, Double> factors = new HashMap<Integer, Double>();
 		for (ExerciseFactor row : list) { 
  			factors.put(row.getKey(), row.getValue());
 		}
 		HealthStream.setExerciseFactors(factors);
 	}
	
	@Given("^I am a (\\d+) years old man in \"([^\"]*)\" health$")
	public void I_am_a_years_old_man_in_health(int arg1, String arg2) {
		insured = new Insured(arg2, arg1);
		quote = new Quote();
		quote.setInsured(insured);
	}

	@Given("^I only exercise (\\d+) times a week$")
	public void I_only_exercise_times_a_week(int arg1) {
		insured.setExerciseFrequency(arg1);
	}

	@When("^I ask for a (\\d+) year term$")
	public void I_ask_for_a_year_term(int years) {
		quote.setYears(years);
	}

	@Then("^my monthly premium will be (\\d+)$")
	public void my_monthly_premium_will_be(int balance) {
		int actual = quote.calc();
		Assert.assertEquals(balance, actual);
	}

	@Then("^my status should be \"([^\"]*)\"$")
	public void my_status_should_be(String arg1) {
		Assert.assertEquals(arg1,quote.getStatus());
	}
 
}
