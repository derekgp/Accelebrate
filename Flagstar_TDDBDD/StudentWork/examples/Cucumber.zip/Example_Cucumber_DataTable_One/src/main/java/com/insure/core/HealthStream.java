package com.insure.core;

import java.util.Map;

public class HealthStream {
	
	private static Map<String, Double> healthFactors;
	private static Map<Integer, Double> exerciseFactors;

	public static Map<String, Double> getHealthFactors() {
		return healthFactors;
	}

	public static void setHealthFactors(Map<String, Double> healthFactors) {
		HealthStream.healthFactors = healthFactors;
	}

	public static Map<Integer, Double> getExerciseFactors() {
		return exerciseFactors;
	}

	public static void setExerciseFactors(Map<Integer, Double> exerciseFactors) {
		HealthStream.exerciseFactors = exerciseFactors;
	}

}
