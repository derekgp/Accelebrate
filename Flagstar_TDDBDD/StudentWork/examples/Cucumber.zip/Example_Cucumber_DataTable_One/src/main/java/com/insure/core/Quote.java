package com.insure.core;

public class Quote {
	
	private Insured insured;
	private int years;
	
 

	public Insured getInsured() {
		return insured;
	}

	public void setInsured(Insured insured) {
		this.insured = insured;
	}

	public void setYears(int years) {
		this.years = years;
	}

	public int calc() {
		return (int) (getHealthFactor() * insured.getAge()) ;
 
	}
	
	private double getHealthFactor(){
		double result = 1.0;
		result = result * HealthStream.getHealthFactors().get(insured.getHealth()); 
 		result = result * HealthStream.getExerciseFactors().get(insured.getExerciseFrequency()); 
		return  result;
	}

	public String getStatus() {
		String status = "rejected";
		if(calc() < 40){
			status = "approved";
		}
		return status;
	} 
 
}
