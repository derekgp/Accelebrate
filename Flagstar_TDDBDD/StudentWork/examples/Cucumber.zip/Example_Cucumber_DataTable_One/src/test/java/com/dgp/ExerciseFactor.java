package com.dgp;

public class ExerciseFactor {
	
	private int key;
	private double value;
	
	public int getKey() {
		return key;
	}
	
	public double getValue() {
		return value;
	}
	 
	 

}
