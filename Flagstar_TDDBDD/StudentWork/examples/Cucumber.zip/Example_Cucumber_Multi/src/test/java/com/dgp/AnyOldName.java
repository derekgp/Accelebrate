package com.dgp;

import junit.framework.Assert;

import com.dgp.stock.StockQuote;

import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
 
public class AnyOldName {
	
	private StockQuote stockQuote;
	
	@Given("^I have a stock ticker of \"([^\"]*)\"$")
	public void I_ahave_a_stock_ticker_of(String arg1) {
	     stockQuote = new StockQuote();
	     stockQuote.setTicker(arg1);
	}

	@When("^I ask for (\\d+) shares$")
	public void I_ask_for_a_shares(int arg1) {
		stockQuote.setShares(arg1);
	}

	@Then("^I will need (\\d+) dollars$")
	public void I_will_need_dollars(int arg1) {
	   Assert.assertEquals(arg1, stockQuote.getPrice());
	}


}
