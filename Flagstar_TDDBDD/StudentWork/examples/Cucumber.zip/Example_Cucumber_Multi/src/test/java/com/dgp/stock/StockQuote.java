package com.dgp.stock;

public class StockQuote {
	
	private String ticker;
	private int qty;

	public void setTicker(String arg1) {
		this.ticker = arg1;
	}

	public void setShares(int arg1) {
		qty = arg1;
	}

	public Object getPrice() {
		int result = 0;
		if(ticker.contains("I")){
			result = 30;
		} else {
			result = 10;
		}
		return result * qty;
	}

}
